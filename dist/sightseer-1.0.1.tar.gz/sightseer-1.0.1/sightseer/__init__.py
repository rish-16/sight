# __init__.py
__version__ = "1.0.1"

from sightseer.sightseer import Sightseer
from sightseer.zoo import *
from sightseer.proc import *