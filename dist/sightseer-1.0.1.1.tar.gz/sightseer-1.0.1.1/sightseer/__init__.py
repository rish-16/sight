# __init__.py
__version__ = "1.0.1.1"

from sightseer.sightseer import Sightseer
import sightseer.zoo
import sightseer.proc