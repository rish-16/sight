# __init__.py
__version__ = "1.1.0"

from sightseer.sightseer import Sightseer
import sightseer.zoo
import sightseer.proc