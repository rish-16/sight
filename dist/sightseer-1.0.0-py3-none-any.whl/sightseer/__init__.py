# __init__.py
__version__ = "1.0.0"

from sight.sightseer import Sightseer
from sight.zoo import *
from sight.proc import *